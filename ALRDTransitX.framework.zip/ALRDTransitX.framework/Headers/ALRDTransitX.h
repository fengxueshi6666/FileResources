//
//  ALRDTransitX.h
//  ALRDTransitX
//
//  Created by 冯学仕 on 2023/6/1.
//

#import <Foundation/Foundation.h>

//! Project version number for ALRDTransitX.
FOUNDATION_EXPORT double ALRDTransitXVersionNumber;

//! Project version string for ALRDTransitX.
FOUNDATION_EXPORT const unsigned char ALRDTransitXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ALRDTransitX/PublicHeader.h>
